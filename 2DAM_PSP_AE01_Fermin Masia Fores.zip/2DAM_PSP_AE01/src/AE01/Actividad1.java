package AE01;

public class Actividad1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		sayHello();
	}
	
	public static void sayHello () {
		System.out.println("¡Hola mundo!");
	} 
}
