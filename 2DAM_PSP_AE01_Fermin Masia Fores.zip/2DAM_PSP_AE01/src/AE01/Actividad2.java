package AE01;

import java.util.ArrayList;
import java.util.Scanner;

public class Actividad2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		int numeroini = 0;
		int numerofin = 0;
		int cont = 0;
		ArrayList <Integer> numeros = new ArrayList ();
		
		do {
		System.out.println("Dime de que numero a que numero quieres sacar los primos, dime ahora el numero de inicio:");
		numeroini = teclado.nextInt();
		System.out.println("Dime ahora el numero de fin:");
		numerofin = teclado.nextInt();
		if (numerofin < numeroini) {
			System.out.println("Vuelva a probar, el numero del inicio tiene que ser menor que el del final.");
		}else if (numeroini == numerofin) {
			System.out.println("Vuelva a probar, los numeros no pueden ser iguales, el numero del inicio tiene que ser menor que el del final.");
		}
		}while(numeroini >= numerofin);
		
		for (int i = numeroini; i <= numerofin; i++) {
			numeros.add(i);
			cont++;
		}
		
		ArrayList <Integer> numerosprim = getPrimos(numeros);
		
		System.out.println("Los numeros primos son:");
		for (int p : numerosprim) {
			System.out.print(p + " ");
		}
	}
	
	
	
	
	public static ArrayList<Integer> getPrimos (ArrayList <Integer> numeros) {
		ArrayList <Integer> numprimo = new ArrayList ();
		
		
		for (int p : numeros) {
			if (p % 2 != 0) {
				if(p % 3 != 0) {
					numprimo.add(p);
				}
			}
			if (p == 2 || p == 3) {
				numprimo.add(p);
			}
		}
		
		return numprimo;
	}
	

}
