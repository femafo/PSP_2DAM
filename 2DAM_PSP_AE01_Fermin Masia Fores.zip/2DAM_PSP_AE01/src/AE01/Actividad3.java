package AE01;

import java.util.ArrayList;
import java.util.Scanner;

public class Actividad3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		String [] listapersonas = {"Xavier", "Fran", "Fermin", "Antonio", "Ivan", "Andriy"};
		ArrayList <Integer> listanumeros = new ArrayList();
		String persona;
		int continuarn;
		Boolean continuar = false;
		int numero;
		int nummayor;
		ArrayList <Integer> numpersonas = new ArrayList();
		
		do {
			System.out.println("Introduzca un numero:");
			numero = teclado.nextInt();
			listanumeros.add(numero);
			do {
				System.out.println("¿Desea continuar?\n1.-Si\n2.-No");
				continuarn = teclado.nextInt();
				switch (continuarn) {
					case 1:
						continuar = true;
						break;
					case 2:
						continuar = false;
						break;
					default:
						System.out.println("Por favor, seleccione una opcion correcta.");
				}
			}while (continuarn != 1 && continuarn != 2);
		}while (continuar == true);
		
		nummayor = numMayor(listanumeros);
		numpersonas = getNombres(listanumeros);
		
		System.out.println("El numero mas grande es el " + nummayor);
		
		if (numpersonas.size() == 0) {
			System.out.println("No hay ningun nombre que coincida con ningun numero.");
		}else {
			for (int n : numpersonas) {
				System.out.println("El numero " + n + " coincide con " + listapersonas[n]);
			}
		}
		
	}
	
	public static int numMayor (ArrayList <Integer> numeros) {
		int numeromayor = 0;
		
		for (int n : numeros) {
			if (n >= numeromayor) {
				numeromayor = n;
			}
		}
		
		return numeromayor;
	}
	
	public static ArrayList <Integer> getNombres (ArrayList <Integer> numeros){
		ArrayList <Integer> personas = new ArrayList();
		
		for (int n : numeros) {
			if (n >= 0 && n <= 5) {
				personas.add(n);
			}
		}
		
		return personas;
		
		
		
	}

}
