package Act1;

public class Main1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num1 = 2;
		int num2 = 3;
		int suma = num1 + num2;
		
		System.out.println(num1 + " + " + num2 + " = " + suma);

	}

}
