package Act1;

import java.util.Scanner;

public class Main11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		int dni;
		char[] letra = {'T','R','W','A','G','M','Y','F','P','D','X','B','N','J','Z','S','Q','V','H','L','C','K','E'};
		int resto;
		
		System.out.println("Dime tu numero del dni:");
		dni = teclado.nextInt();
		
		resto = dni % 23;
		System.out.println("La letra de tu dni es: " + letra[resto]);
	}

}
