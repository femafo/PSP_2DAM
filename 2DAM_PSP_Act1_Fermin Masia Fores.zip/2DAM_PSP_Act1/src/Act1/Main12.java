package Act1;

import java.util.Scanner;

public class Main12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		
		int []notas = new int [10];
		int csuspensos = 0;
		int caprobados = 0;
		int cnotable = 0;
		int csobresaliente = 0;
		int cmatrhon = 0;
		
		for (int i = 0; i < 10; i++) {
			System.out.println("Dime una nota:");
			notas[i] = teclado.nextInt();
			
			if (notas[i] >= 0 && notas[i] <=4) {
				csuspensos++;
			}
			if (notas[i] >= 5 && notas[i] <=6) {
				caprobados++;
			}
			if (notas[i] >= 7 && notas[i] <=8) {
				cnotable++;
			}
			if (notas[i] == 9) {
				csobresaliente++;
			}
			if (notas[i] == 10) {
				cmatrhon++;
			}
		}
		
		System.out.println("Suspensos: " + csuspensos);
		System.out.println("Aprobados: " + caprobados);
		System.out.println("Notables: " + cnotable);
		System.out.println("Sobresaliente: " + csobresaliente);
		System.out.println("Matricula de honor: " + cmatrhon);

	}

}
