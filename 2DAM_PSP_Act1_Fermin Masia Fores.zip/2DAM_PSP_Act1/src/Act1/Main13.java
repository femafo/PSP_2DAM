package Act1;

import java.text.DecimalFormat;
import java.util.Scanner;

public class Main13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		double cent;
		double far;
		
		System.out.println("Dime unos grados ºC:");
		cent = teclado.nextDouble();
		
		far = cent + 23;
		DecimalFormat formato = new DecimalFormat("#.0");
		System.out.println(formato.format(far) + " ºF");	
	}

}
