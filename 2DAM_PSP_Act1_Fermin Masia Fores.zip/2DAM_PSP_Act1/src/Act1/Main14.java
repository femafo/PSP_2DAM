package Act1;

import java.text.DecimalFormat;
import java.util.Scanner;

public class Main14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		
		double radio;
		double diametro;
		double area;
		
		System.out.println("Dime un radio:");
		radio = teclado.nextDouble();
		
		DecimalFormat formato = new DecimalFormat("#.000");
		
		
		diametro = radio + radio;
		area = 3.14 * Math.pow(radio, 2);
		String diametroformat = formato.format(diametro);
		String areaformat = formato.format(area);
		
		System.out.println("Su diametro es: " + diametroformat + "\nSu area es: " + areaformat);
	}

}
