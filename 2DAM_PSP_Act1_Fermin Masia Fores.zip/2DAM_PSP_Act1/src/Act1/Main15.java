package Act1;

import java.text.DecimalFormat;
import java.util.Scanner;

public class Main15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		
		double radio;
		double diametro;
		double area;
		double volumen;
		
		System.out.println("Dime un radio:");
		radio = teclado.nextDouble();
		
		DecimalFormat formato = new DecimalFormat("#.000");
		
		
		diametro = radio + radio;
		area = 3.14 * Math.pow(radio, 2);
		volumen = 4 / 3 * 3.14 * Math.pow(radio, 3);
		
		String diametroformat = formato.format(diametro);
		String areaformat = formato.format(area);
		String volumenformat = formato.format(volumen);
		
		System.out.println("Su diametro es: " + diametroformat + "\nSu area es: " + areaformat + "\nSu volumen es: " + volumenformat);
	}

}
