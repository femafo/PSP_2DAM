package Act1;

import java.util.Scanner;

public class Main16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		int dia;
		int mes;
		int ano;
		int nsuerte;
		
		System.out.println("Dime el dia en que naciste");
		dia = teclado.nextInt();
		System.out.println("Dime ahora el mes de tu nacimiento en numeros");
		mes = teclado.nextInt();
		System.out.println("Por ultimo dime el año en el que naciste en numeros");
		ano = teclado.nextInt();
		
		nsuerte = ano / mes * 2 - dia;
		System.out.println("Tu numero de la suerte es: " + nsuerte);
	}

}
