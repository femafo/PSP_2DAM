package Act1;

import java.util.Scanner;

public class Main17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		
		String contrasena;
		boolean tieneNumero = false;
        boolean tieneMayuscula = false;
        boolean tamano = true;
		
		System.out.println("Dime tu contrasena");
		contrasena = teclado.next();
		
		if (contrasena.length() < 5) {
            tamano = false;
        }
		for (char c : contrasena.toCharArray()) {
            if (Character.isDigit(c)) {
                tieneNumero = true;
            }
            if (Character.isUpperCase(c)) {
                tieneMayuscula = true;
            }
        }
		
		if(tieneNumero == true && tieneMayuscula == true && tamano == true) {
			System.out.println("Contraseña valida");
			
		}else {
			System.out.println("Contraseña invalida");
		}
		
        
	}

}
