package Act1;

public class Main19 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i = 0; i <= 127; i++) {
            System.out.println("Código ASCII: " + i + " -> Carácter: " + (char) i);
        }
	}

}
