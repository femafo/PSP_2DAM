package Act1;

import java.util.Scanner;

public class Main2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		String nombre;
		
		System.out.println("¿Como te llamas?");
		nombre = teclado.next();
		
		System.out.println("Hola " + nombre);
		
		

	}

}
