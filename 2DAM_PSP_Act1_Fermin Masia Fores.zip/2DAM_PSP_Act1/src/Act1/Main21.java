package Act1;

import java.util.Scanner;

public class Main21 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		String[] nombres = new String[5];
		
		for (int i = 0; i < 5; i++) {
            System.out.println("Introduce el nombre de la persona " + (i + 1) + ": ");
            nombres[i] = teclado.nextLine();
        }
		
		System.out.println("Los nombres introducidos son:");
        for (String nombre : nombres) {
            System.out.println(nombre);
        }
	}

}
