package Act1;

import java.util.ArrayList;
import java.util.Scanner;

public class Main22 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);

        ArrayList<String> nombres = new ArrayList<>();

        String nombre;

        while (true) {
            System.out.print("Introduce el nombre de una persona (o 0 para terminar): ");
            nombre = teclado.nextLine();
            
            if (nombre.equals("0")) {
                break;
            }
            
            nombres.add(nombre);
        }

        System.out.println("Los nombres introducidos son:");
        for (String nom : nombres) {
            System.out.println(nom);
        }

	}

}
