package Act1;

import java.util.ArrayList;
import java.util.Scanner;

public class Main23 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);

        ArrayList<String> nombres = new ArrayList<>();

        String nombre;

        while (true) {
            System.out.print("Introduce el nombre de una persona (o 0 para terminar): ");
            nombre = teclado.nextLine();
            
            if (nombre.equals("0")) {
                break;
            }
            
            nombres.add(nombre);
        }

        System.out.println("\nLos nombres introducidos son:");
        for (int i = 0; i < nombres.size(); i++) {
            System.out.println((i + 1) + ". " + nombres.get(i));
        }
	}

}
