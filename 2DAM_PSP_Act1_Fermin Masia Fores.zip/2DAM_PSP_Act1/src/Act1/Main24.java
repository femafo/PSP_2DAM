package Act1;

import java.util.Random;
import java.util.Scanner;

public class Main24 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		int numero;
		int opc;
		
		System.out.println("Dime un numero del 1 al 10:");
		numero = teclado.nextInt();
		
		Random rand = new Random();
        int numeroAleatorio = rand.nextInt(10) + 1;
        
        System.out.println("Tu numero es el: " + numero + "\nEl de la maquina es el: " + numeroAleatorio);
        if(numero == numeroAleatorio) {
        	System.out.println("Enorabuena has ganado, elige tu premio\n1.-Cena romantica con CR7\n2.-Foto firmada por Antonio Recio\n3.-Un llavero de Marisco Recio (el mar al mejor precio) exclusivo");
        	opc = teclado.nextInt();
        	do {
        	switch(opc) {
        		case 1:
        			System.out.println("SUUUUUUU");
        			break;
        		case 2:
        			System.out.println("Si quiere una cena elegante, llevese un bogavante");
        			break;
        		case 3:
        			System.out.println("Disfrutalo, pocos van a tener uno igual");
        			break;
        		default:
        			System.out.println("Introduce una opcion valida");
        	}
        	}while(opc < 1 || opc > 3);
        	
        }else {
        	System.out.println("Lastima has perdido vuelve a probar");
        }
		
	}

}
