package Act1;

import java.util.ArrayList;
import java.util.Scanner;

public class Main28 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		
		String tipo;
		String marca;
		String modelo;
		ArrayList<Vehiculo> vi = new ArrayList<>();
		int cont = 1;
		
		
		for (int i = 0; i < 5; i++) {
			System.out.println("Dime la tipo del vehiculo " + (i + 1) + ":");
			tipo = teclado.next();
			System.out.println("Dime la marca del vehiculo " + (i + 1) + ":");
			marca = teclado.next();
			System.out.println("Dime la modelo del vehiculo " + (i + 1) + ":");
			modelo = teclado.next();
			
			Vehiculo v = new Vehiculo (tipo, modelo, marca);
			
			vi.add(v); 
		}
		
		for (Vehiculo ve : vi) {
			System.out.println("Vehiculo " + cont + ": " + ve.getTipo() + ", " + ve.getMarca() + ", " + ve.getModelo());
			cont++;
		}
	}

}
