package Act1;

import java.util.ArrayList;
import java.util.Scanner;

public class Main29 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		
		String tipo;
		String marca;
		String modelo;
		ArrayList<Vehiculo> vi = new ArrayList<>();
		int cont = 1;
		boolean continuar = true;
		int i = 0; 
		String contin;
		
		do {
				System.out.println("Dime la tipo del vehiculo " + (i + 1) + ":");
				tipo = teclado.next();
				System.out.println("Dime la marca del vehiculo " + (i + 1) + ":");
				marca = teclado.next();
				System.out.println("Dime la modelo del vehiculo " + (i + 1) + ":");
				modelo = teclado.next();
				
				Vehiculo v = new Vehiculo (tipo, modelo, marca);
				
				vi.add(v);
				System.out.println("¿Desea continuar? s/n");
				contin = teclado.next();
				
				if (contin.equals("s")) {
					continuar = true;
				}
				if (contin.equals("n")) {
					continuar = false;
				}
				i++;
				
		}while(continuar == true);
		
		
		
		for (Vehiculo ve : vi) {
			System.out.println("Vehiculo " + cont + ": " + ve.getTipo() + ", " + ve.getMarca() + ", " + ve.getModelo());
			cont++;
		}
	}

}
