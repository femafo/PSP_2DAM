package Act1;

public class Main30 {


	/*
	 *Paso 1: Crear un programa Java:
	 *Primero, vamos a escribir un programa Java, o elegir uno (como es nuestro caso) ya creado.
	 *
	 *
	 *
	 *Paso 2: Compilar el programa:
	 *Abre la terminal (o el símbolo del sistema) y navega a la carpeta donde guardaste el archivo. 
	 *Luego, compila el archivo usando el siguiente comando:
	 *"javac EJEMPLO.java"
	 *
	 *
	 *
	 *Paso 3: Crear el archivo JAR:
	 *Ahora, vamos a crear un archivo JAR ejecutable.
	 *Para hacer esto, primero necesitamos crear un archivo de manifiesto.
	 *Crea un archivo llamado MANIFEST.MF con el siguiente contenido:
	 *"Manifest-Version: 1.0
	 * Main-Class: EJEMPLO"
	 *
	 *Asegúrate de que haya una línea en blanco al final del archivo MANIFEST.MF.
	 *Luego, ejecuta el siguiente comando para crear el archivo JAR:
	 *"jar cfm EJEMPLO.jar MANIFEST.MF EJEMPLO.class"
	 *
	 *
	 *
	 *Paso 4: Ejecutar el archivo JAR:
	 *Finalmente, puedes ejecutar el archivo JAR usando el siguiente comando:
	 *"java -jar EJEMPLO.jar"
	 */

}
