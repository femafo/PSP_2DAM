package Act1;

import java.util.Scanner;

public class Main5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		int num1;
		int num2;
		
		do {
		System.out.println("Dime el primer numero:");
		num1 = teclado.nextInt();
		System.out.println("Dime el segundo numero:");
		num2 = teclado.nextInt();
		}while (num1 != num2);
		
		System.out.println(num1 + " = " + num2);
		
	}

}
