package Act1;

import java.util.Scanner;

public class Main6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		int [] num = new int [5];
		int suma = 0;
		
		for ( int i = 0; i < 5; i++) {
			int cont = i + 1;
			System.out.println("Dime el numero " + cont + ":");
			num[i] = teclado.nextInt();
			suma = suma + num[i];
		}
		System.out.println("La suma de los numeros introducidos es: " + suma);
	}

}
