package Act1;

import java.util.Scanner;

public class Main7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		int [] num = new int [5];
		int suma = 0;
		int i = 0;
		do {
			int cont = i + 1;
			System.out.println("Dime el numero " + cont + ":");
			num[i] = teclado.nextInt();
			suma = suma + num[i];
			i++;
		}while (i < 5); 
		System.out.println("La suma de los numeros introducidos es: " + suma);
	}

}
