package Act1;

import java.util.Scanner;

public class Main9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		int mesnum = 0;
		
		do {
			System.out.println("Dime un numero:");
			mesnum = teclado.nextInt();
			if (mesnum == 1) {
				System.out.println("Enero");
			}
			if (mesnum == 2) {
				System.out.println("Febrero");
			}
			if (mesnum == 3) {
				System.out.println("Marzo");
			}
			if (mesnum == 4) {
				System.out.println("Abril");
			}
			if (mesnum == 5) {
				System.out.println("Mayo");
			}
			if (mesnum == 6) {
				System.out.println("Junio");
			}
			if (mesnum == 7) {
				System.out.println("Julio");
			}
			if (mesnum == 8) {
				System.out.println("Agosto");
			}
			if (mesnum == 9) {
				System.out.println("Septiembre");
			}
			if (mesnum == 10) {
				System.out.println("Octubre");
			}
			if (mesnum == 11) {
				System.out.println("Noviembre");
			}
			if (mesnum == 12) {
				System.out.println("Diciembre");
			}
			if(mesnum < 1 || mesnum > 12) {
				System.out.println("FALLO, pon un numero del 1 al 12");
			}
		}while(mesnum < 1 || mesnum > 12);
		
	}

}
